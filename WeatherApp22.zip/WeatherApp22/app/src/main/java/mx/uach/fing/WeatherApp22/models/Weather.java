package mx.uach.fing.WeatherApp22.models;

public class Weather {
    public String city;
    public String weather;
    public String temp;
    public Integer id;
}
